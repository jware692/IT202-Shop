<?php
//TODO 1: require db.php
require_once(__DIR__."/db.php");
//require safer_echo.php
require_once(__DIR__ . "/safer_echo.php");
//TODO 2: filter helpers

//TODO 3: User helpers

//TODO 4: Flash Message Helpers
?>