### Templates and partial files go here. Basically stuff that won't directly be accessed via the URL
