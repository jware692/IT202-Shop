IT-202-008
Akashdeep

Hi! Im a CS major taking this course to satisfy my lower level computing elective, but I also want to learn more about web development.
