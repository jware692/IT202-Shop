### Keep your library/shared files here so they're not accessible via the browser. PHP will still be able to fetch them via include/require.
